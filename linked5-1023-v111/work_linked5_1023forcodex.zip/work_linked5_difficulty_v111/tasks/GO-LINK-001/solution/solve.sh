#!/bin/bash
set -euo pipefail
python3 /solution/reference.py --domain GO --input /app/input_files --output /app/output
