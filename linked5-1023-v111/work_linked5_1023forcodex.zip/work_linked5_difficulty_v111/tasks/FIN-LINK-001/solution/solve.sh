#!/bin/bash
set -euo pipefail
python3 /solution/reference.py --domain FIN --input /app/input_files --output /app/output
