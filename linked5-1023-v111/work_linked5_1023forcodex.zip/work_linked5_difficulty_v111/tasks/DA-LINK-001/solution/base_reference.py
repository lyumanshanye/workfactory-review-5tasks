"""Reproducible author candidates. Independent expert acceptance is still required."""
from pathlib import Path
import argparse, json, math, re
from datetime import date, timedelta
import numpy as np
import pandas as pd
from lxml import html, etree
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pypdf import PdfReader


def frame(rows):return pd.DataFrame(rows)
def fnum(x,d=2):return '缺失' if pd.isna(x) else f'{x:,.{d}f}'
def xlsx(path,sheets):
    with pd.ExcelWriter(path,engine='openpyxl') as writer:
        for name,data in sheets.items():data.to_excel(writer,sheet_name=name,index=False)
    wb=load_workbook(path)
    for ws in wb:
        ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
        for c in ws[1]:c.fill=PatternFill('solid',fgColor='16324F');c.font=Font(color='FFFFFF',bold=True);c.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=32
        for col in ws.columns:
            letter=col[0].column_letter
            ws.column_dimensions[letter].width=min(66,max(14,max(len(str(c.value or '')) for c in list(col)[:250])+2))
            for c in list(col)[1:]:
                c.alignment=Alignment(vertical='top',wrap_text=True)
                if isinstance(c.value,float):c.number_format='#,##0.0000;[Red](#,##0.0000);0.0000'
    wb.save(path)

def doc(path,title,lead,sections):
    d=Document();sec=d.sections[0];sec.top_margin=Inches(.7);sec.bottom_margin=Inches(.7)
    style=d.styles['Normal'];style.font.name='Arial';style.font.size=Pt(10)
    style.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei')
    d.add_heading(title,0);d.add_paragraph(lead)
    for heading,content in sections:
        d.add_heading(heading,1)
        if isinstance(content,pd.DataFrame):
            t=d.add_table(rows=1,cols=len(content.columns));t.style='Light Shading Accent 1'
            for c,s in zip(t.rows[0].cells,content.columns):c.text=str(s)
            for row in content.itertuples(index=False,name=None):
                for c,s in zip(t.add_row().cells,row):c.text=str(s)
            available=sec.page_width-sec.left_margin-sec.right_margin
            weights=content.attrs.get('column_widths',[1]*len(content.columns));t.autofit=False
            for column,weight in zip(t.columns,weights):column.width=int(available*weight/sum(weights))
            for row in t.rows:
                row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
                for cell,weight in zip(row.cells,weights):
                    cell.width=int(available*weight/sum(weights))
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:run.font.size=Pt(9)
            t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        else:
            for s in content if isinstance(content,list) else [content]:d.add_paragraph(s)
    d.save(path)

def csv(data,path):data.to_csv(path,index=False,encoding='utf-8-sig')
def pdf_pages(path,term):
    r=PdfReader(path)
    return [i+1 for i,p in enumerate(r.pages) if term.lower() in (p.extract_text() or '').lower()]

def source_rows(d,inp):
    page,needle,base={
        'GO':('gsa_per_diem_files.html','FY2026','https://www.gsa.gov/travel/plan-a-trip/per-diem-rates/per-diem-files'),
        'FIN':('fdic_api_documentation.html','risview_properties.yaml','https://api.fdic.gov/banks/docs/'),
        'LAW':('ftc_safeguards_guide.html','/current/title-16/chapter-I/subchapter-C/part-314','https://search.ftc.gov/business-guidance/resources/ftc-safeguards-rule-what-your-business-needs-know'),
        'DA':('epa_download_files.html','FileFormats.html','https://aqs.epa.gov/aqsweb/airdata/download_files.html'),
        'GA':('uci_dota2_dataset.html','da-steve101','https://archive.ics.uci.edu/dataset/367/dota2+games+results')}[d]
    t=html.fromstring((inp/page).read_bytes());a=next((a for a in t.xpath('//a[@href]') if needle in a.get('href')),None)
    if a is not None:href=a.get('href');context=' '.join(a.text_content().split())
    else:
        text=t.text_content();href=re.search(r'https://gist\.github\.com/da-steve101/[a-z0-9]+',text).group();context='UCI正文显式URL引用'
    from urllib.parse import urljoin
    return [dict(source=page,locator=context,reference=urljoin(base,href),use='网页实际引用；下游材料用于本题同一业务决定。')]


def go(inp,out):
    cities=[('Chicago','IL','Chicago',218,410,80,9500),('Denver','CO','Denver / Aurora',209,340,70,10500),('Phoenix','AZ','Phoenix / Scottsdale',155,510,90,8000)]
    rateframes={y:pd.read_excel(inp/f'FY{y}_PerDiemMasterRatesFile.xlsx',header=1) for y in [2025,2026]}
    tab=Document(inp/'GSA_FY2025_MIE_Breakdown.docx').tables[0]
    breakdown={int(r.cells[0].text.replace('$','')):[float(c.text.replace('$','')) for c in r.cells[1:]] for r in tab.rows[1:]}
    def md(s):
        m,day=str(s).split();return (pd.to_datetime(m,format='%B').month,int(day))
    def lookup(city,state,y,dt):
        d=rateframes[y];d=d[d.STATE.eq(state)&d.DESTINATION.eq(city)]
        for ix,r in d.iterrows():
            start,end=md(r['SEASON BEGIN']),md(r['SEASON END']);cur=(dt.month,dt.day)
            if (start<=cur<=end) if start<=end else (cur>=start or cur<=end):return ix+3,r
        raise ValueError((city,y,dt))
    daily=[];options=[];sources=source_rows('GO',inp)
    dates=pd.date_range('2025-09-28','2025-10-02')
    meals={28:['dinner'],29:['lunch'],30:['lunch'],1:['lunch','dinner'],2:['lunch']}
    for name,state,dest,quote,air,local,venue in cities:
        per=[]
        for dt in dates:
            y=2025 if dt.month==9 else 2026;row,r=lookup(dest,state,y,dt)
            mie=float(r[f'FY{str(y)[2:]} M&IE']);cap=float(r[f'FY{str(y)[2:]} Lodging Rate'])
            breakfast,lunch,dinner,incident,travel=breakdown[int(mie)]
            supplied=meals[dt.day];ded=sum({'breakfast':breakfast,'lunch':lunch,'dinner':dinner}[x] for x in supplied)
            factor=.75 if dt==dates[0] or dt==dates[-1] else 1
            payable=max(incident,mie*factor-ded);lodging=quote if dt!=dates[-1] else 0
            tax=lodging*.12;ok=quote<=cap
            per.append(dict(city=name,date=dt.date().isoformat(),fiscal_year=y,source=f'FY{y}_PerDiemMasterRatesFile.xlsx',excel_row=row,lodging_cap=cap,lodging_quote=quote,paid_lodging=lodging,lodging_tax=tax,MIE_full=mie,travel_factor=factor,government_meals=','.join(supplied),meal_deduction=ded,incidental_floor=incident,MIE_payable=payable,hotel_breakfast_deduction=0,refreshment_deduction=0,lodging_compliant=ok))
        daily+=per
        sums={k:sum(x[k] for x in per) for k in ['paid_lodging','lodging_tax','MIE_payable']}
        for n in [18,24]:
            perperson=sum(sums.values())+air+local+180;base=perperson*n+venue;reserve=base*.05;stress=base+.2*air*n
            options.append(dict(city=name,attendees=n,**sums,air_per_person=air,local_per_person=local,registration_per_person=180,per_person=perperson,venue=venue,base=base,reserve=reserve,total=base+reserve,headroom=53000-base-reserve,compliant=all(x['lodging_compliant'] for x in per),eligible=all(x['lodging_compliant'] for x in per) and base*1.05<=53000,stress_base=stress,stress_total=stress*1.05,stress_headroom=53000-stress*1.05))
        for y in [2025,2026]:
            subset=[x for x in per if x['fiscal_year']==y]
            sources.append(dict(source=f'FY{y}_PerDiemMasterRatesFile.xlsx',locator=','.join(str(x['excel_row']) for x in subset),reference=name,use='按旅行日财政年度和季节匹配；报价计费，上限仅用于合规比较。'))
    opt=frame(options);chosen=opt[opt.eligible].sort_values(['attendees','total','city'],ascending=[False,True,True]).iloc[0]
    fallback=opt[opt.eligible & (opt.stress_total<=53000)].sort_values(['attendees','total','city'],ascending=[False,True,True]).iloc[0]
    sources+= [dict(source='eCFR_41_CFR_301-11.xml',locator='301-11.17/.18/.27/.101',reference='2025-01-01冻结版',use='免费早餐不扣；政府供餐从首末日75%额扣整餐；最低杂费保护；税另计。'),dict(source='eCFR_41_CFR_301-74.xml',locator='301-74.7/.9/.21',reference='2025-01-01冻结版',use='茶歇与住宿安全/会议审批边界。'),dict(source='instruction.md',locator='场景假设表及预算条件',reference='非真实报价、税率或已审批采购',use='12%税、5%储备、53000上限、人数与机票等。')]
    register=frame([
        dict(item='旅行及报销授权',owner='差旅审批员',evidence='行程、四晚单间报价、逐日费率和供餐记录；确认未申请超标准实际费用',due='订票/承诺费用之前',blocks_approval='是'),
        dict(item='住宿与消防安全',owner='会务协调员',evidence='确认场所符合301-74.9及适用安全要求的证明；不能仅凭价格推定',due='签约之前',blocks_approval='是'),
        dict(item='场地采购与供餐范围',owner='采购负责人',evidence='报价有效性、场地合同、注册与供餐不重复计费、内部采购程序',due='采购承诺之前',blocks_approval='是'),
        dict(item='资金与压力情景',owner='预算负责人',evidence=f"确认{chosen.city} {int(chosen.attendees)}人含储备{chosen.total:.2f}；压力时批准追加资金或减至{int(fallback.attendees)}人",due='资金承诺之前及出票时复核',blocks_approval='是'),
        dict(item='实际费用授权',owner='差旅审批员',evidence='本方案报价未超标准；若后续超标，应按301-11.300/.302申请，不能自动获准',due='发生超标费用前',blocks_approval='条件阻断')])
    xlsx(out/'conference_budget.xlsx',{'Daily':frame(daily),'Options':opt,'Sources':frame(sources)});csv(register,out/'approval_register.csv')
    doc(out/'approval_brief.docx','培训会预算批准建议',f"建议有条件选择{chosen.city}、{int(chosen.attendees)}人，基础预算${chosen.base:,.2f}，5%储备${chosen.reserve:,.2f}，批准总额${chosen.total:,.2f}，余量${chosen.headroom:,.2f}。在材料补齐前不作采购承诺。",[
        ('方案比较',opt[['city','attendees','base','reserve','total','headroom','stress_total']].round(2).rename(columns={'city':'城市','attendees':'人数','base':'基础费用','reserve':'储备','total':'批准总额','headroom':'预算余量','stress_total':'压力总额'})),
        ('规则和证据',['GSA下载页实际引用FY2026工作簿；FY2025和餐费拆分文件同页可追溯。两财政年度在本题三地日期的住宿及M&IE费率未发生变化；不同版本仍须分别匹配，原表行号见Daily/Sources。','301-11.101：首末日75%；301-11.18：在降低后的额度扣整份供餐金额，杂费下限保留。301-11.17：酒店免费早餐不扣；301-74.21：茶歇不扣。住宿按218/209/155实际报价、四晚计费，12%税为内部假设，税不含在住宿上限中；本题报价均不超上限。']),
        ('压力措施',f"机票上浮20%时首选含储备${chosen.stress_total:,.2f}，预算余量${chosen.stress_headroom:,.2f}。可先锁定机票价格，无法锁定时申请${max(0,-chosen.stress_headroom):,.2f}追加额度；否则使用{fallback.city}、{int(fallback.attendees)}人压力下仍可承受的方案（${fallback.stress_total:,.2f}）。这属于内部预算建议。"),
        ('批准前补证',register),('假设边界','表中报价、税率、人数和费用均为题设情景。未核验真实酒店、供应商、消防、采购程序或资金可用性；差旅与场地批准条件见登记表。')])
    return dict(recommendation=chosen.city,attendees=int(chosen.attendees),total=float(chosen.total),stress_total=float(chosen.stress_total),options=len(opt))


def fin(inp,out):
    d=pd.read_csv(inp/'fdic_financials_VT_NH_ME_2022_2025.csv');d.insert(0,'source_row',np.arange(len(d))+2)
    inst=pd.read_csv(inp/'fdic_institutions_VT_NH_ME.csv',low_memory=False)
    assert not d.duplicated(['CERT','REPDTE']).any()
    counts=inst.CERT.value_counts();unique=inst[inst.CERT.map(counts).eq(1)].set_index('CERT')
    d['institution_matches']=d.CERT.map(counts).fillna(0);d['institution_ACTIVE_snapshot']=d.CERT.map(unique['ACTIVE'])
    def ratio(a,b):return 100*a/b.where(b>0)
    d['proxy_numerator']=d.P9ASSET+d.NAASSET;d['proxy_pct']=ratio(d.proxy_numerator,d.ASSET)
    d['RE_loan_share_pct']=ratio(d.LNRE,d.LNLSGR);d['equity_asset_pct']=ratio(d.EQ,d.ASSET)
    valid=d[d.proxy_pct.notna()].copy();dates=sorted(d.REPDTE.unique());audit=[]
    for k,v in dict(financial_rows=len(d),unique_banks=d.CERT.nunique(),quarters=len(dates),duplicate_bank_quarters=d.duplicated(['CERT','REPDTE']).sum(),institution_rows=len(inst),duplicate_institution_CERT=inst.CERT.duplicated().sum(),unmatched_financial_rows=(d.institution_matches==0).sum(),ambiguous_financial_rows=(d.institution_matches>1).sum(),zero_or_missing_assets=(~d.ASSET.gt(0)).sum(),missing_proxy=d.proxy_pct.isna().sum()).items():audit.append(dict(check=k,CERT='',value=int(v)))
    for cert,g in d.groupby('CERT'):
        missing=sorted(set(dates)-set(g.REPDTE));audit.append(dict(check='missing_quarters',CERT=cert,value=','.join(map(str,missing)) or 'none'))
    for c in ['RUNDATE','RISDATE']:
        if c in inst:audit.append(dict(check='institution_snapshot_'+c,CERT='',value=';'.join(map(str,inst[c].dropna().unique()[:8]))))
    peers=[]
    for dt,g in valid.groupby('REPDTE'):
        for state,part in [('ALL',g)]+list(g.groupby('STALP')):
            peers.append(dict(REPDTE=int(dt),state=state,banks=part.CERT.nunique(),ASSET_thousand=part.ASSET.sum(),proxy_numerator_thousand=part.proxy_numerator.sum(),proxy_pct=100*part.proxy_numerator.sum()/part.ASSET.sum()))
    start,end=20240630,20250630;a=valid[valid.REPDTE.eq(start)].set_index('CERT');b=valid[valid.REPDTE.eq(end)].set_index('CERT');common=a.index.intersection(b.index)
    bridge=[]
    for state in ['ALL','ME','NH','VT']:
        aa=a if state=='ALL' else a[a.STALP.eq(state)];bb=b if state=='ALL' else b[b.STALP.eq(state)]
        cc=common if state=='ALL' else common[b.loc[common,'STALP'].eq(state)]
        w=a.loc[cc,'ASSET'];fixed0=(a.loc[cc,'proxy_pct']*w).sum()/w.sum();fixed1=(b.loc[cc,'proxy_pct']*w).sum()/w.sum()
        obs0=100*aa.proxy_numerator.sum()/aa.ASSET.sum();obs1=100*bb.proxy_numerator.sum()/bb.ASSET.sum()
        entering=bb.index.difference(aa.index);exiting=aa.index.difference(bb.index)
        bridge.append(dict(state=state,start_banks=len(aa),end_banks=len(bb),common_banks=len(cc),observed_start_pct=obs0,observed_end_pct=obs1,observed_change_pp=obs1-obs0,fixed_start_pct=fixed0,fixed_end_pct=fixed1,fixed_change_pp=fixed1-fixed0,scope_reweight_residual_pp=(obs1-obs0)-(fixed1-fixed0),entering_CERT=','.join(map(str,entering)),exiting_CERT=','.join(map(str,exiting)),entering_end_assets=bb.loc[entering,'ASSET'].sum(),exiting_start_assets=aa.loc[exiting,'ASSET'].sum()))
    rank=b.reset_index().sort_values(['proxy_pct','CERT'],ascending=[False,True]);selected=[]
    for state in ['VT','NH','ME']:selected.append(int(rank[rank.STALP.eq(state)].iloc[0].CERT))
    selected+= [int(c) for c in rank.CERT if c not in selected][:8-len(selected)]
    priority=[]
    for i,cert in enumerate(selected,1):
        r=b.loc[cert];prior=a.loc[cert] if cert in a.index else None
        priority.append(dict(rank=i,CERT=cert,state=r.STALP,bank=r.NAMEFULL,proxy_pct=r.proxy_pct,prior_proxy_pct=prior.proxy_pct if prior is not None else np.nan,change_pp=r.proxy_pct-prior.proxy_pct if prior is not None else np.nan,RE_loan_share_pct=r.RE_loan_share_pct,equity_asset_pct=r.equity_asset_pct,ROA_pct=r.ROA,RBCRWAJ_pct=r.RBCRWAJ,source_row=int(r.source_row),prior_source_row=int(prior.source_row) if prior is not None else '',reason=f"最新资产代理率{r.proxy_pct:.4f}%，先州覆盖再全域高值；待核实成因",request='提供90天以上仍计息与非应计资产台账、分类及担保/还款材料；提供房地产贷款分层集中度与抵押估值；核对盈利和资本变动桥接及资产口径',owner='信用复核负责人',due='委员会后5个工作日内提交初核包'))
    priority=frame(priority);peers=frame(peers);bridge=frame(bridge)
    pages=pdf_pages(inp/'FDIC_RMS_Manual_3.2_Loans.pdf','loan review')
    sources=source_rows('FIN',inp)+[
        dict(source='financial_definitions.yaml',locator='ASSET, NAASSET, P9ASSET, ROA, RBCRWAJ',reference='FDIC API Financial definitions',use='ROA为已年化百分数；P9ASSET与NAASSET为资产口径代理，非监管评级。'),
        dict(source='institution_definitions.yaml',locator='CERT, ACTIVE',reference='FDIC API Institution definitions',use='CERT主键与更晚机构快照；不按ACTIVE删除历史。'),
        dict(source='FDIC_RMS_Manual_3.2_Loans.pdf',locator='Loan Review Systems；本地PDF页'+','.join(map(str,pages[:5])),reference='Section 3.2 Loans',use='复核贷款质量、集中风险、分类、还款及内部贷款审查，代理指标不足以独立评级。'),
        dict(source='instruction.md',locator='金额口径与核查名额规则',reference='本次桌面练习明确设定',use='金额千美元、先州覆盖后区域高值；排序门槛不是监管规定。')]
    xlsx(out/'credit_review.xlsx',{'DataAudit':frame(audit),'BankQuarter':d,'PeerQuarter':peers,'EndpointBridge':bridge,'Priority':priority,'Sources':frame(sources)})
    csv(priority,out/'follow_up_register.csv');region=bridge[bridge.state.eq('ALL')].iloc[0]
    bank_display=frame([{'银行（证书号／州）':str(r.bank)+'\n'+str(r.CERT)+' / '+str(r.state),'当期代理率%':round(r.proxy_pct,4),'同比变化pp':round(r.change_pp,4)} for r in priority.itertuples()]);bank_display.attrs['column_widths']=[.64,.18,.18]
    doc(out/'credit_review_memo.docx','季度信用复核及名额分配',f"区域资产代理率从{region.observed_start_pct:.4f}%变为{region.observed_end_pct:.4f}%（{region.observed_change_pp:+.4f}个百分点）。八个核查名额按三州覆盖约束分配，不能将该排序作为银行评级。",[
        ('范围及口径',[f"金融CSV共{len(d)}行、{d.CERT.nunique()}家银行、{len(dates)}个季度。CERT+季度无重复；机构资料{len(inst)}行；机构连接未匹配{int((d.institution_matches==0).sum())}行、歧义{int((d.institution_matches>1).sum())}行。机构日期为更晚快照，不使用ACTIVE筛除历史。逐家缺失季度和资料日期见DataAudit。",'FDIC文档页明确引用risview_properties.yaml和institution_properties.yaml，字段核对后再计算。金额按题设千美元；ROA已经年化且以百分数表示。代理率为(P9ASSET+NAASSET)/ASSET，房地产占比以LNLSGR为分母。']),
        ('观察变化与固定权重',bridge[['state','observed_start_pct','observed_end_pct','observed_change_pp','fixed_change_pp','scope_reweight_residual_pp']].round(5).rename(columns={'state':'州','observed_start_pct':'原期%','observed_end_pct':'当期%','observed_change_pp':'观察变化pp','fixed_change_pp':'固定权重变化pp','scope_reweight_residual_pp':'范围/权重差pp'})),
        ('如何解释变化',f"共同银行以2024-06-30资产固定加权，区域变化{region.fixed_change_pp:+.4f}个百分点；与观察变化的差{region.scope_reweight_residual_pp:+.4f}个百分点同时含范围和权重变化，不能说纯为银行恶化或单一成因。州固定集合按最新州别，进入/退出CERT及金额见EndpointBridge。"),
        ('八家核查分配',bank_display),
        ('需要什么证据',[f"贷款手册Section 3.2的Loan Review Systems（本地PDF页{','.join(map(str,pages[:5]))}）支持以独立贷款复核核验分类及质量。高资产代理率不是贷款不良率、不是违规证据；也不能据此判断资不抵债。",'每家请求90天以上与非应计资产明细、分类/还款及担保材料、房地产集中度与抵押估值，再将盈利与资本变动对应到业务原因。委员会后五个工作日只是内部管理时限。各州覆盖选择和后续区域补足见Priority顺序，CSV逐家列证据。']),
        ('结论边界','本次是冻结数据回顾，不是以2026机构快照回测2025时点可用信息。缺失不补零；权重和资产口径需保留。待拿到贷款级证据后再谈信用判断。')])
    return dict(rows=len(d),banks=int(d.CERT.nunique()),quarters=len(dates),selected_CERT=selected,regional_observed_change_pp=float(region.observed_change_pp),regional_fixed_change_pp=float(region.fixed_change_pp))


def law(inp,out):
    discovered=date(2025,3,3);deadline=discovered+timedelta(days=30)
    # Read the frozen operative source before deriving scenario conclusions.
    tree=etree.parse(str(inp/'eCFR_16_CFR_314_2025-01-01.xml'))
    text=' '.join(tree.xpath('//text()'));assert 'May 13, 2024' in text and 'five thousand' in text
    rows=[
      ('未指定Qualified Individual','法定义务适用','314.4(a)','4800人例外未含(a)','指定有能力者并书面明确职责；如外包保留机构责任','管理层','今天确认负责人、7天内落实','任命和能力/监督证明'),
      ('无书面风险评估','特定书面义务豁免；一般风险评估仍适用','314.4(b)、(b)(1)、314.6','4800<5000，仅(b)(1)被豁免','启动基于事件的风险识别；建议书面留痕但不称书面义务法定适用','Qualified Individual','7天初评、30天复核','风险判断与控制处置记录'),
      ('无MFA','法定义务适用，注意规则允许的替代条件','314.4(c)(5)','无已给出的合格替代控制事实','对访问客户信息者部署MFA；如确实不能用，需QI书面批准等效安全措施','信息安全负责人','今天限制暴露，7天完成优先账户','MFA覆盖/测试；或替代评估与QI批准'),
      ('无持续监控或渗透测试','(d)(2)特定测试豁免；(d)(1)一般测试/监测适用','314.4(d)(1)、(d)(2)、314.6','不能由免年度渗透测试推定免所有监测','立即保留日志、建立监测并验证关键控制；渗透测试可自愿采用','安全运营','今天保全，7天初核','日志/告警及控制有效性证据'),
      ('无书面事件应急计划','(h)法定书面计划豁免；自愿建议制定','314.4(h)、314.6','4800人例外含(h)，但通报和安全计划仍适用','建议在事件处置中形成书面分工和流程','管理层/安全负责人','今天明确分工，30天形成演练版','流程、演练与沟通清单'),
      ('无年度董事会安全报告','(i)特定义务豁免；自愿治理建议','314.4(i)、314.6','4800人例外含(i)','建议向高管报告事件与剩余风险，不声称法定年度报告逾期','Qualified Individual','7天初报、30天复核','高管知悉和处置决定'),
      ('云服务合同无安全义务','法定义务适用','314.4(f)(1)-(3)','小机构例外不含(f)','核验供应商安全能力、补充合同要求并按风险定期评估','采购/法务/安全负责人','今天要求保全日志，7天补充条款方案','合同、安全评估、服务商响应证据'),
      ('仅通用入职培训，无安全持续更新','法定义务适用','314.4(e)','不能据已培训推定符合持续安全知识要求','补充针对安全风险的人员培训、关键人员更新与知识核验','人事/安全负责人','7天优先培训、30天复核','培训内容、参加与验证记录'),
      ('已发生550人通知事件','法定义务适用','314.2(m)、314.4(j)、314.5','加密密钥失窃，非涉事员工03-03已确认','尽快准备并电子向FTC通报，不等待管理层报告日；仅本题草稿不发送','合规负责人/法务','尽快；最迟2025-04-02','审核的六类信息、正式提交确认（未来待办）')]
    obligations=frame([dict(gap=a,status=b,citation=c,fact=d,action=e,owner=f,internal_due=g,completion_evidence=h) for a,b,c,d,e,f,g,h in rows])
    timeline=frame([
      dict(date='2024-05-13',event='314.4(j)生效',effect='事件发生在生效后；314.5'),
      dict(date='2025-03-01/2025-03-02',event='攻击者访问、下载数据且获密钥',effect='550名消费者的notification event'),
      dict(date='2025-03-03 09:00',event='非涉事员工Alex确认',effect='314.4(j)(2)归属机构知悉，开始发现后日历天计算'),
      dict(date='2025-03-06',event='管理层读报告',effect='不重启发现时点'),
      dict(date='2025-03-07',event='警方仅口头请求不公开，顾问调查',effect='没有书面执法决定；不暂停FTC报送'),
      dict(date=deadline.isoformat(),event='发现后30日最迟FTC通报',effect='还须尽快，不能有意等至最后一日')])
    scenarios=frame([
      dict(consumers_maintained=4800,affected=550,exemption='(b)(1),(d)(2),(h),(i)',FTC_notice='是',safeguards='其余义务仍适用'),
      dict(consumers_maintained=5000,affected=550,exemption='不适用fewer than 5000例外',FTC_notice='是',safeguards='题述四项特定义务也不再豁免'),
      dict(consumers_maintained=4800,affected=499,exemption='(b)(1),(d)(2),(h),(i)',FTC_notice='本假设不达(j)至少500门槛',safeguards='安全计划和其余义务不因此消失；人数需持续核实')])
    p2023=pdf_pages(inp/'FR_2023-24412_Safeguards_Breach_Notification.pdf','May 13, 2024')
    p2021=pdf_pages(inp/'FR_2021-25736_Safeguards_Rule_Final.pdf','5,000')
    sources=source_rows('LAW',inp)+[
      dict(source='eCFR_16_CFR_314_2025-01-01.xml',locator='314.2(m),314.4(a)-(j),314.5,314.6',reference='冻结适用版',use='定义、一般安全义务、通报、2024-05-13生效及小机构例外。'),
      dict(source='eCFR_16_CFR_314_2021-12-01.xml',locator='314.4',reference='旧版对照',use='不含此后新增的详细控制和(j)通知制度，不能用于本事件豁免判断。'),
      dict(source='FR_2021-25736_Safeguards_Rule_Final.pdf',locator='本地PDF涉及5000消费者页'+','.join(map(str,p2021[:5])),reference='2021最终规则',use='2021细化控制和小机构例外来源。'),
      dict(source='FR_2023-24412_Safeguards_Breach_Notification.pdf',locator='本地PDF生效信息页'+','.join(map(str,p2023)),reference='2023-24412',use='新增FTC通报；现有314.5确认生效日。'),
      dict(source='instruction.md',locator='全部事件/机构事实',reference='明确假设情景',use='并非来源记录或真实法律委托；不外联、不提交。')]
    xlsx(out/'safeguards_gap_register.xlsx',{'Obligations':obligations,'Timeline':timeline,'Scenarios':scenarios,'Sources':frame(sources)})
    notice='''假设演练 — FTC Safeguards Rule电子通报正文草稿 — 未提交
本草稿仅为题设业务情景，不代表真实事件或已完成通知。

1. 报告机构及联系方式
Harbor Education Finance LLC；合规负责人Dana Lee；compliance@example.invalid；+1-202-555-0100。均为题设合成联系人，正式提交前须核验。

2. 涉及信息类型
客户姓名、地址、贷款账号及余额。导出文件加密，但攻击者同时取得解密密钥；按314.2(m)不能以加密排除本事件。

3. 事件日期或日期范围
2025-03-01至2025-03-02；2025-03-03 09:00非涉事员工Alex确认访问和下载。具体调查仍在进行。

4. 受影响或可能受影响人数
当前已知550名不同消费者，均包含于本机构维护客户信息的4800人中。未发现其他受影响者；如调查变化需核实并更新，不把当前数字说成已穷尽所有影响。

5. 事件一般描述
攻击者未经授权访问并下载加密客户导出文件，同时获得解密密钥。没有可靠证据否定未授权取得。管理层03-06读到报告，顾问03-07开始调查，不改变03-03发现时点。调查、保全和止损仍在进行；本草稿不声称修复、客户通知或FTC提交已完成。

6. 执法书面决定及联系信息
截至题设2025-03-07没有执法人员关于公开将妨碍刑事调查或损害国家安全的书面决定。警方只有口头不公开请求，无指定延期长度；没有可填写的书面决定或已给出的执法联系人。若收到适格书面决定，核验其内容并提供FTC联系执法人员的方式；不得编造联系人。口头请求不当然延期向FTC提交。

准备说明
依据314.4(j)，拟尽快由有权限人员核验后通过FTC电子表格提交，最迟2025-04-02。此为内容草稿，未打开提交表格、未发送任何通知；正式提交的必要机构细节如法定地址若需填写，应另行核实，不补造。
'''
    (out/'ftc_notice_draft.txt').write_text(notice)
    doc(out/'legal_action_memo.docx','安全事件处置法律行动意见','本题需尽快向FTC通报。发现日2025-03-03，最迟2025-04-02；4800人的特定控制例外不免除550人事件的通报义务。本意见及草稿均为假设演练，未发送。',[
      ('适用规则和引用链',[f"FTC业务指南实际链接到eCFR Part 314及具体条款，Sources记录原链接。以2025-01-01冻结XML为适用版，当前网页仅检索。2021旧XML用于比较；2021最终规则细化QI、控制及小机构例外，2023最终规则增加(j)，314.5记载2024-05-13生效。2023 PDF本地页{','.join(map(str,p2023))}可核对。",'公司受FTC规则覆盖为题设，不重新推断真实管辖。314.2(m)定义notification event：未授权取得未加密客户信息；密钥被未授权取得使加密信息按未加密处理；未授权访问存在推定取得且无可靠反证。本案已明确下载且550人，达到至少500门槛。']),
      ('小机构例外与缺口',obligations[['gap','status','citation']]),
      ('事件时间与执法请求',['314.4(j)(2)使非涉事员工Alex在03-03的知悉归属于机构。03-06管理层、03-07顾问不是新的起算点。发现日之后30个日历日为04-02，仍须as soon as possible。','314.4(j)(1)(vi)涉及执法书面决定和公开延迟：最初可请求在向FTC通知后最多30日，书面申请可再延长最多60日，进一步须FTC工作人员判断。这里仅口头请求，无适格书面材料，也不是对FTC报送的自动暂停。应请警方澄清/书面化，但不以此等待报送。']),
      ('立即行动和内部期限',['今天：合规负责人/法务核实550人数、数据及发现时点，组织电子通报审核；安全人员保全日志、收回泄露密钥并限制暴露，记录未完成事项。管理层确认Qualified Individual职责与资源。','7天内：QI核对一般风险评估与有效监测，优先落实MFA、供应商安全义务与针对性培训；补证和实际完成情况写入登记。','30天内：核验改进有效性、复查服务商与剩余风险，建议自愿形成书面响应流程并向高管报告。今天/7天/30天是内部建议，不是法规授权宽限；不能据此推迟FTC尽快报告。']),
      ('边界情景',scenarios),('待核实范围','原始机构身份、完整受影响范围、证据保全与正式电子表格细节仍须核实。州法及其他监管/客户通知义务不在所给法律材料确定范围内，需另行核查。不得将本草稿当作完成通知。')])
    return dict(discovery=discovered.isoformat(),deadline=deadline.isoformat(),FTC_notice_required=True,exemptions=['314.4(b)(1)','314.4(d)(2)','314.4(h)','314.4(i)'])


def da(inp,out):
    raw=pd.read_csv(inp/'daily_aqi_by_county_2024.csv');raw['source_row']=np.arange(len(raw))+2
    annual=pd.read_csv(inp/'annual_aqi_by_county_2024.csv');annual['source_row']=np.arange(len(annual))+2
    county=pd.read_csv(inp/'national_county2020.txt',sep='|',dtype=str)
    counties=['Maricopa','Pima','Yuma'];d=raw[raw['State Name'].eq('Arizona') & raw['county Name'].isin(counties)].copy()
    d['FIPS']=d['State Code'].astype(int).astype(str).str.zfill(2)+d['County Code'].astype(int).astype(str).str.zfill(3)
    d['date']=pd.to_datetime(d.Date);assert not d.duplicated(['FIPS','date']).any()
    audit=[];recon=[];calendar=[]
    names=['Good Days','Moderate Days','Unhealthy for Sensitive Groups Days','Unhealthy Days','Very Unhealthy Days','Hazardous Days']
    for name,g in d.groupby('county Name'):
        fips=g.FIPS.unique().item();match=county[(county.STATEFP+county.COUNTYFP).eq(fips)];assert len(match)==1 and match.iloc[0].COUNTYNAME==name+' County'
        values=pd.to_numeric(g.AQI,errors='coerce');g=g.copy();g['AQI']=values
        full=g.set_index('date').reindex(pd.date_range('2024-01-01','2024-12-31'));full['county']=name;full['FIPS']=fips
        audit.append(dict(county=name,FIPS=fips,census_name=match.iloc[0].COUNTYNAME,observed_rows=len(g),valid_AQI=int(values.notna().sum()),calendar_days=len(full),missing_dates=','.join(full.index[full.AQI.isna()].strftime('%Y-%m-%d')),duplicate_keys=0,invalid_AQI=int(values.isna().sum()),min_sites=g['Number of Sites Reporting'].min(),max_sites=g['Number of Sites Reporting'].max(),site_missing=int(g['Number of Sites Reporting'].isna().sum()),source_rows=f"{g.source_row.min()}..{g.source_row.max()}"))
        bins=pd.cut(values,[-np.inf,50,100,150,200,300,np.inf],labels=names).value_counts().to_dict();metrics={'Days with AQI':int(values.notna().sum()),'Max AQI':values.max(),**{c:int(bins.get(c,0)) for c in names}}
        ar=annual[annual.State.eq('Arizona') & annual.County.eq(name) & annual.Year.eq(2024)];assert len(ar)==1;ar=ar.iloc[0]
        for k,v in metrics.items():recon.append(dict(county=name,FIPS=fips,metric=k,recomputed=v,annual_value=ar[k],difference=v-ar[k],annual_source_row=int(ar.source_row),status='一致' if v==ar[k] else '差异：保留原件，需查来源版本/覆盖'))
        for dt,r in full[full.index.dayofweek<5].iterrows():
            observed=pd.notna(r.AQI);aq=float(r.AQI) if observed else np.nan
            amove=int(observed and aq>=101);bmove=int(observed and aq>=151);missing=int(not observed);diff=amove-bmove
            actionA='待测，室内备用' if missing else '室内' if amove else '户外'
            actionB='待测，室内备用' if missing else '室内' if bmove else '低强度户外并提供室内选项' if aq>=101 else '户外'
            calendar.append(dict(FIPS=fips,county=name,date=dt.date().isoformat(),source_row=int(r.source_row) if pd.notna(r.source_row) else '',AQI=aq,sites=r['Number of Sites Reporting'],observed=observed,action_A=actionA,action_B=actionB,A_threshold_indoor=amove,B_threshold_indoor=bmove,missing_indoor_backup=missing,A_extra_indoor=diff,A_extra_potential_participant_hours=diff*60,month=dt.strftime('%Y-%m')))
    cal=frame(calendar).sort_values(['FIPS','date']);cols=['A_threshold_indoor','B_threshold_indoor','missing_indoor_backup','A_extra_indoor','A_extra_potential_participant_hours']
    def summarize(keys):
        result=cal.groupby(keys).agg(sessions=('date','size'),**{c:(c,'sum') for c in cols}).reset_index()
        for c in ['A_threshold_indoor','B_threshold_indoor','missing_indoor_backup']:result[c+'_potential_hours']=result[c]*60
        return result
    monthly=summarize(['county','month']);summary=summarize(['county']);total=dict(county='ALL',**{c:summary[c].sum() for c in summary.columns if c!='county'});summary=pd.concat([summary,frame([total])],ignore_index=True)
    sources=source_rows('DA',inp)+[dict(source='epa_file_formats.html',locator='Daily AQI by County / Annual AQI by County',reference='日表和年表字段说明',use='日指标与年汇总的对应，不提供活动小时AQI或健康因果。'),dict(source='AQI_Technical_Assistance_Document.pdf',locator='AQI categories',reference='0–50,51–100,101–150,151–200,201–300,301+',use='按数值重算分档，年度对账。'),dict(source='national_county2020.txt',locator='04 + county code',reference='Maricopa/Pima/Yuma County',use='FIPS身份核对，不是健康结果。'),dict(source='instruction.md',locator='工作日、40人、90分钟、A/B动作',reference='明确业务假设',use='每场60潜在参与人时；非真实出勤。')]
    xlsx(out/'outdoor_activity_model.xlsx',{'DataAudit':frame(audit),'AnnualReconciliation':frame(recon),'Monthly':monthly,'CountySummary':summary,'Sources':frame(sources)});csv(cal,out/'review_calendar.csv')
    top=monthly.sort_values(['A_extra_indoor','county','month'],ascending=[False,True,True]).head(5);delta=int(total['A_extra_indoor']);diffcount=int((frame(recon).difference!=0).sum())
    doc(out/'activity_policy_brief.docx','三县户外活动室内备用政策复盘',f"共{len(cal)}个拟安排工作日场次。政策A相对B多转室内{delta}场、{delta*60}潜在参与人时；两者相同的缺测室内备用另计{int(total['missing_indoor_backup'])}场。建议保留B的分级安排，同时为敏感人群提供A级室内选择，并按县月准备弹性容量。",[
      ('各县资源需求',summary[['county','sessions','A_threshold_indoor','B_threshold_indoor','missing_indoor_backup','A_extra_indoor']].rename(columns={'county':'县','sessions':'拟安排场次','A_threshold_indoor':'A超标室内','B_threshold_indoor':'B超标室内','missing_indoor_backup':'缺测备用','A_extra_indoor':'A额外室内'})),('差异集中月份',top[['county','month','A_threshold_indoor','B_threshold_indoor','A_extra_indoor','A_extra_potential_participant_hours']].rename(columns={'county':'县','month':'月份','A_threshold_indoor':'A超标室内','B_threshold_indoor':'B超标室内','A_extra_indoor':'A额外室内','A_extra_potential_participant_hours':'额外潜在人时'})),
      ('覆盖与对账',[f"三县各补齐366日，原始日记录数{len(d)}；FIPS由州县代码构造并与Census县名核对。缺测见DataAudit，逐日原始行号在日历；不会填0或用年度总数补造日期。日表重算六档、有效日和最大值对年表的24项核对，非零差异{diffcount}项。",'年表差异如出现应回查快照版本与监测范围，不能修改原件或强行认定某表错误。日历仅周一至周五，包含节假日；年度对账使用全年全部观测日。']),
      ('运营行动',['优先为差异集中县月预订可按日启用的室内空间。每天在活动前查当时可获得的实时/预报与场地信息，再做运行决定；本题最终日AQI只能回顾模拟。','B下101–150降低强度并提供室内选项；资源核算中的B超标室内仅统计>=151，不能假称敏感人群因此无需保护。A更保守但多占室内容量，负责人应结合参与者构成和可用场地选择。','缺测日单独按待测室内备用管理，不能把缺测算成超标或两种政策差异。每场40×1.5=60是题设潜在人时，不是真实出勤。']),
      ('解释边界','县日AQI不是某活动小时或个人暴露；站点数量和覆盖会影响观察。没有健康结果，不能推断哮喘因果。2024以外年份、下一年精确超标天数或当前实时风险均不能由本历史模拟确定。')])
    return dict(daily_rows=len(d),calendar_rows=len(cal),extra_indoor=delta,extra_hours=delta*60,annual_nonzero_differences=diffcount,missing_dates={x['county']:x['missing_dates'] for x in audit})


def wilson(w,n):
    if not n:return (np.nan,np.nan)
    p=w/n;z=1.96;den=1+z*z/n;ctr=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return ctr-half,ctr+half

def ga(inp,out):
    train=pd.read_csv(inp/'dota2Train.csv',header=None);test=pd.read_csv(inp/'dota2Test.csv',header=None)
    globalp=train[0].eq(1).mean();baselines=train.groupby([1,2,3])[0].agg(n='size',p=lambda x:x.eq(1).mean());lookup={(int(a),int(b),int(c)):(r.p if r.n>=100 else globalp,int(r.n<100)) for (a,b,c),r in baselines.iterrows()}
    def expected(d):
        vals=[lookup.get(tuple(map(int,x)),(globalp,1)) for x in d[[1,2,3]].itertuples(index=False,name=None)]
        return np.array([x[0] for x in vals]),np.array([x[1] for x in vals])
    stats={};audit=[]
    for split,d in [('train',train),('test',test)]:
        signs=d.iloc[:,4:].to_numpy(dtype=int);labels=d[0].to_numpy(dtype=int);p,fallback=expected(d);rows=[]
        audit.append(dict(split=split,rows=len(d),columns=d.shape[1],missing_cells=int(d.isna().sum().sum()),invalid_labels=int((~d[0].isin([-1,1])).sum()),invalid_hero_values=int((~d.iloc[:,4:].isin([-1,0,1])).sum().sum()),bad_team_counts=int(((signs==1).sum(axis=1)!=5).sum()+((signs==-1).sum(axis=1)!=5).sum()),exact_duplicate_rows=int(d.duplicated().sum()),plus_side_win_pct=100*d[0].eq(1).mean(),clusters=d[1].nunique(),modes=d[2].nunique(),types=d[3].nunique()))
        for h in range(113):
            sg=signs[:,h];active=sg!=0;win=sg==labels;n=int(active.sum());wins=int((win & active).sum());exp=np.where(sg==1,p,1-p);raw=wins/n if n else np.nan;ex=exp[active].mean() if n else np.nan;lo,hi=wilson(wins,n)
            rec=dict(H=f'H{h+1:03}',csv_column=h+5,n=n,n_plus=int((sg==1).sum()),n_minus=int((sg==-1).sum()),wins=wins,raw_win_pct=100*raw,expected_pct=100*ex,adjusted_gap_pp=100*(raw-ex),wilson_low_pct=100*lo,wilson_high_pct=100*hi,fallback_share_pct=100*fallback[active].mean() if n else np.nan)
            for side,nm in [(1,'plus'),(-1,'minus')]:
                mask=sg==side;rec[nm+'_gap_pp']=100*((win[mask].mean()-exp[mask].mean()) if mask.any() else np.nan)
            rec['eligible']=n>=1000 and rec['n_plus']>=200 and rec['n_minus']>=200;rows.append(rec)
        stats[split]=frame(rows)
    eligible=stats['train'][stats['train'].eligible]
    hi=eligible.sort_values(['adjusted_gap_pp','H'],ascending=[False,True]).head(3);lo=eligible.sort_values(['adjusted_gap_pp','H'],ascending=[True,True]).head(3)
    frozen=pd.concat([hi.assign(direction='high'),lo.assign(direction='low')],ignore_index=True);assert frozen.H.nunique()==6
    review=frozen.merge(stats['test'],on=['H','csv_column'],suffixes=('_train','_test'),validate='one_to_one')
    review['replication']=np.where((review.n_test>=100)&(review.adjusted_gap_pp_train*review.adjusted_gap_pp_test>0),'方向复现','未复现/支持不足')
    cross=int(pd.util.hash_pandas_object(test,index=False).isin(pd.util.hash_pandas_object(train,index=False)).sum())
    audit.append(dict(split='cross_split',rows=cross,columns='精确整行交集数量；非match ID去重，不能排除全部重复对局'))
    queue=[]
    for ix,r in review.iterrows():
        direction='偏高' if r.direction=='high' else '偏低'
        queue.append(dict(H=r.H,selection_direction=r.direction,train_gap_pp=r.adjusted_gap_pp_train,test_gap_pp=r.adjusted_gap_pp_test,test_n=int(r.n_test),replication=r.replication,hypothesis=f"{r.H}在受控阵容/环境中是否仍有{direction}的胜负关联，而非阵营和样本构成所致",control='同一版本、同等玩家水平及角色组成配对；交换阵营/选用与不选用该英雄，记录cluster/mode/type；先独立核对英雄槽位身份',metric='主要：配对试玩胜率差；辅助：两阵营与模式分层结果、样本支持度',support='足量、预先约定样本下跨阵营方向一致，独立复核效应超出预先约定实际重要性界限',refute='配对控制后信号消失/反向，或只存在于单一阵营/稀疏层；不以单次胜负确认',owner='平衡设计师与数据分析师',priority=(1 if r.replication=='方向复现' else 2),confounding=f"训练正方{r.plus_gap_pp_train:+.3f}pp/负方{r.minus_gap_pp_train:+.3f}pp；训练回退{r.fallback_share_pct_train:.2f}%，测试回退{r.fallback_share_pct_test:.2f}%"))
    queue=frame(queue);sources=source_rows('GA',inp)+[
        dict(source='uci_dota2_dataset.html',locator='Dataset Information / Variable Information / visible gist and mapping URLs',reference='UCI Dota2 Games Results, 2016',use='117列；胜方与英雄符号；两小时采样及原始split。'),
        dict(source='dota2_collector_page.html',locator='matchId / player_hero_data / CSV writer',reference='UCI正文所引采集代码',use='采集代码输出matchId、胜方、cluster、模式、类型和10英雄ID的15列原始格式；不能默认等同117列指示矩阵。'),
        dict(source='heroes_mapping.json',locator='heroes[].id/name/localized_name',reference='UCI所引映射仓库快照',use='映射含ID与名称，但未核实指示列生成/ID排序；仅用稳定槽位H001-H113。'),
        dict(source='instruction.md',locator='基线、支持度、排序及复核规则',reference='练习业务分析约定',use='训练选六项，保留集只验证；不输出当前版本改动。')]
    xlsx(out/'balance_review.xlsx',{'DataAudit':frame(audit),'TrainSignals':stats['train'],'FrozenSix':frozen,'HoldoutReview':review,'Sources':frame(sources)});csv(queue,out/'playtest_queue.csv')
    display=review[['H','direction','n_train','adjusted_gap_pp_train','n_test','adjusted_gap_pp_test','replication']].copy();display=display.round(4).replace({'direction':{'high':'高','low':'低'}}).rename(columns={'H':'槽位','direction':'方向','n_train':'训练场次','adjusted_gap_pp_train':'训练差pp','n_test':'测试场次','adjusted_gap_pp_test':'测试差pp','replication':'方向复核'})
    doc(out/'balance_review_brief.docx','历史对局信号与试玩建议',f"仅训练数据冻结六项假设，保留集{int((review.replication=='方向复现').sum())}/6项达到题定方向复现条件。优先检查已复现方向的假设，未复现项目作为反证调查；不直接发布英雄数值改动。",[
        ('数据与来源核对',[f"训练{train.shape[0]}×{train.shape[1]}、测试{test.shape[0]}×{test.shape[1]}。标签±1，英雄113列值-1/0/+1且每方五人；详细质量检查见DataAudit。跨split精确整行交集{cross}，没有match ID，不能宣称排除了所有对局泄漏。",'UCI正文确实引用gist采集代码和heroes.json。被引用代码的原始输出是15列而不是117列；引用存在不能证明格式转换。映射JSON有ID但缺少可信的指示矩阵生成/排序证据，因此交付只用H001-H113，与第5至117列逐一对应。正号英雄在标签+1时胜，负号英雄在标签-1时胜。']),
        ('冻结六项及保留复核',display),
        ('分析方法',[f"训练总体+1方胜率{100*globalp:.4f}%。cluster/mode/type层训练>=100用层胜率，否则总体回退；每次英雄出场按所在阵营取p或1-p。校正差=原始胜率-预期率，以百分点表示。全部113项见TrainSignals，训练合格项取最高三和最低三，按H编号打破并列。",'测试沿用冻结训练基线，未重估也未重选。测试支持>=100且校正差严格同号才标方向复现；两split分方差和回退占比见HoldoutReview。原始胜率Wilson 95%区间z=1.96只针对原始率，不能当作校正差显著性。六项为探索性多重比较，不作显著性或因果宣告。']),
        ('试玩实施',['队列逐项写出假设、训练与测试证据、阵营混杂、配对对照、观察指标和推翻条件。方向复现者优先级1，未复现者优先级2；可因设计资源调整优先顺序，但不能改写训练冻结名单。','先在实际试玩系统核实槽位身份和当前版本，再在玩家水平、阵容/角色及模式相近条件下安排配对和交换阵营。预先约定样本量与实际重要性界限，未给定参数不伪称材料规定。']),
        ('限制','2016两小时观测窗口及原始split不代表时间外推验证。没有补丁版本、玩家技能、角色和完整对局ID，分层校正只处理三个可见编码，不排除选角协同与玩家差异。不能把历史关联直接外推当前版本或宣布必须削弱/增强。')])
    return dict(train_rows=len(train),test_rows=len(test),cross_exact_rows=cross,selected=frozen.H.tolist(),replicated=review.loc[review.replication.eq('方向复现'),'H'].tolist())


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True,choices=['GO','FIN','LAW','DA','GA']);p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    result=globals()[a.domain.lower()](a.input,a.output)
    print(json.dumps(result,ensure_ascii=False))
