#!/bin/bash
set -euo pipefail
python3 /solution/reference.py --domain DA --input /app/input_files --output /app/output
