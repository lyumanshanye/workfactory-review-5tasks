"""Author oracle for the explicit v1.1 constraints; not an independent Gold."""
from pathlib import Path
from datetime import date,timedelta
import argparse,importlib.util,itertools,json,math
import numpy as np
import pandas as pd
from docx import Document

def load_base():
 path=Path(__file__).with_name('base_reference.py')
 if not path.exists():path=Path(__file__).with_name('reference.py')
 spec=importlib.util.spec_from_file_location('original_author_reference',path)
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def append_memo(path,title,paragraphs,table=None):
 doc=Document(path);doc.add_heading(title,1)
 for text in paragraphs:doc.add_paragraph(str(text))
 if table is not None:
  t=doc.add_table(rows=1,cols=len(table.columns));t.style='Light Shading Accent 1'
  for cell,name in zip(t.rows[0].cells,table.columns):cell.text=str(name)
  for row in table.itertuples(index=False,name=None):
   for cell,value in zip(t.add_row().cells,row):cell.text=str(value)
 doc.save(path)

def claim_rows(claims,evidence):
 return pd.DataFrame([dict(id=x['id'],unreviewed_claim=x['statement'],assessment='不采纳该无条件主张',evidence=evidence[i][0],decision_impact=evidence[i][1]) for i,x in enumerate(claims)])

def go(base,inp,out,c):
 rules=c['rules'];cap25=rules['fy_caps']['2025'];cap26=rules['fy_caps']['2026'];sheets=pd.read_excel(out/'conference_budget.xlsx',sheet_name=None)
 rows=[]
 for option in sheets['Options'].itertuples():
  daily=sheets['Daily'][sheets['Daily'].city.eq(option.city)]
  per={fy:sum(g.paid_lodging+g.lodging_tax+g.MIE_payable) for fy,g in daily.groupby('fiscal_year')}
  for scenario,air_multiplier in [('base',1),('air_plus_20pct',1.2)]:
   fy25=(per[2025]+option.air_per_person*air_multiplier+option.local_per_person/2+option.registration_per_person*2/3)*option.attendees+option.venue
   fy26=(per[2026]+option.local_per_person/2+option.registration_per_person/3)*option.attendees
   all25,all26=fy25*1.05,fy26*1.05
   transfer=math.ceil(max(0,all25-rules['fy_caps']['2025']-1e-8)*100)/100
   capacity26=rules['fy_caps']['2026']-all26
   direct=bool(option.compliant and all25<=cap25+1e-8 and all26<=cap26+1e-8)
   conditional=bool(option.compliant and transfer<=rules['transfer_limit']+1e-8 and transfer<=capacity26+1e-8 and all25+all26<=53000+1e-8)
   rows.append(dict(city=option.city,attendees=option.attendees,scenario=scenario,FY2025_base=fy25,FY2025_reserve=fy25*.05,FY2025_total=all25,FY2026_base=fy26,FY2026_reserve=fy26*.05,FY2026_total=all26,total=all25+all26,FY2025_headroom=cap25-all25,FY2026_headroom=capacity26,minimum_transfer_to_FY2025=transfer,transfer_capacity_from_FY2026=capacity26,within_current_caps=direct,feasible_if_transfer_approved=conditional,transfer_status='尚未批准；不视为现有资金'))
   expected=option.total if scenario=='base' else option.stress_total
   assert math.isclose(all25+all26,expected,abs_tol=1e-7)
 bridge=pd.DataFrame(rows)
 def select(scenario,field):
  eligible=bridge[bridge.scenario.eq(scenario)&bridge[field]]
  if eligible.empty:return None
  return eligible.sort_values(['attendees','total','city'],ascending=[False,True,True]).iloc[0]
 direct=select('base','within_current_caps');conditional=select('base','feasible_if_transfer_approved')
 stress=select('air_plus_20pct','within_current_caps')
 def describe(x):
  if x is None:return '无可行方案'
  return f"{x.city} {int(x.attendees)}人，总额{x.total:.2f}，FY2025={x.FY2025_total:.2f}，FY2026={x.FY2026_total:.2f}，最低额度调整{x.minimum_transfer_to_FY2025:.2f}"
 paragraphs=['这是内部管理归集与额度约束，不作联邦拨款法认定。原总额基础对照不等于最终资金批准。',
             '无需年度调整的最终最优方案：'+describe(direct),
             '额度调整获批后才可执行的最优方案：'+describe(conditional),
             '机票上涨20%且无年度调整的最优方案：'+describe(stress),
             f'调整只在两年间移动额度，不能消除总成本超53000或FY2026自身不足。逐方案下界为max(0,FY2025总额-{cap25})，上界为min(1500,{cap26}-FY2026总额)；下界大于上界即不可行。']
 audit=claim_rows(c['unreviewed_internal_claims'],[(paragraphs[1]+'；'+paragraphs[2],'将额度调整列为批准前阻断条件，不跨年度自动挪用。'),('压力情景两年分别按变动后的基础额重新计提5%储备。','出票前重算年度及总额；不能冻结原储备。')])
 sheets.update(FundingBridge=bridge,DecisionAudit=audit);base.xlsx(out/'conference_budget.xlsx',sheets)
 memo=out/'approval_brief.docx';d=Document(memo)
 if len(d.paragraphs)>1:d.paragraphs[1].text='原总预算基础对照：'+d.paragraphs[1].text+' 最终批准以文末分年度资金核验为准。'
 d.save(memo);append_memo(memo,'分年度资金核验与最终批准',paragraphs,bridge[['city','attendees','scenario','minimum_transfer_to_FY2025','within_current_caps','feasible_if_transfer_approved']])
 register=pd.read_csv(out/'approval_register.csv')
 extra=pd.DataFrame([dict(item='分年度资金确认及额度调整',owner='预算负责人/CFO',evidence='；'.join(paragraphs[1:4]),due='承诺支出之前，必要额度调整正式批准后',blocks_approval='是'),dict(item='压力情景重新计提储备',owner='预算负责人/差旅审批员',evidence='FY2025/2026分别重算机票变动后的基础额和5%储备；按FundingBridge执行',due='出票前',blocks_approval='是')])
 base.csv(pd.concat([register,extra],ignore_index=True),out/'approval_register.csv')
 return dict(unconditional=describe(direct),conditional=describe(conditional),stress=describe(stress))

def fin(base,inp,out,c):
 sheets=pd.read_excel(out/'credit_review.xlsx',sheet_name=None);raw=pd.read_csv(inp/'fdic_financials_VT_NH_ME_2022_2025.csv')
 raw['rate']=100*(raw.P9ASSET+raw.NAASSET)/raw.ASSET
 a=raw[raw.REPDTE.eq(20240630)].set_index('CERT');b=raw[raw.REPDTE.eq(20250630)].set_index('CERT');common=a.index.intersection(b.index)
 contributions=[];summaries=[]
 for state in ['ALL','ME','NH','VT']:
  ids=common if state=='ALL' else common[b.loc[common,'STALP'].eq(state)]
  aa,bb=a.loc[ids],b.loc[ids];w0=aa.ASSET/aa.ASSET.sum();w1=bb.ASSET/bb.ASSET.sum()
  within=(w0+w1)/2*(bb.rate-aa.rate);weight=(aa.rate+bb.rate)/2*(w1-w0)
  p0=(w0*aa.rate).sum();p1=(w1*bb.rate).sum()
  obs=float(sheets['EndpointBridge'].set_index('state').loc[state,'observed_change_pp'])
  for cert in ids:contributions.append(dict(state=state,CERT=int(cert),start_rate_pct=aa.loc[cert,'rate'],end_rate_pct=bb.loc[cert,'rate'],start_common_weight=w0.loc[cert],end_common_weight=w1.loc[cert],within_rate_contribution_pp=within.loc[cert],asset_weight_contribution_pp=weight.loc[cert]))
  rec=dict(state=state,common_start_pct=p0,common_end_pct=p1,common_change_pp=p1-p0,within_rate_contribution_pp=within.sum(),asset_weight_contribution_pp=weight.sum(),scope_difference_pp=obs-(p1-p0),observed_change_pp=obs)
  assert math.isclose(rec['common_change_pp'],within.sum()+weight.sum(),abs_tol=1e-10);summaries.append(rec)
 priority=sheets['Priority'].copy();states=c['rules']['full_review_required_states']
 choices=[priority[priority.state.eq(state)].CERT.astype(int).tolist() for state in states]
 combinations=list(itertools.product(*choices));score=lambda ids:sum(float(b.loc[k,'P9ASSET']+b.loc[k,'NAASSET']) for k in ids)
 full=sorted(combinations,key=lambda ids:(-score(ids),tuple(sorted(ids))))[0]
 minimum=len(priority)+2*len(states);gap=minimum-c['rules']['available_days']
 plan=priority[['rank','CERT','state','bank','source_row']].copy()
 plan['current_base_days']=1;plan['conditional_full_review']=plan.CERT.isin(full)
 plan['conditional_extra_days']=plan.conditional_full_review.astype(int)*2
 plan['conditional_total_days']=1+plan.conditional_extra_days
 plan['scope']='基础核查可先行；三州完整方案待追加'+str(gap)+'人日获批'
 plan['proxy_amount_thousand']=plan.CERT.map((b.P9ASSET+b.NAASSET).to_dict())
 assert int(plan.conditional_total_days.sum())==minimum
 audit=claim_rows(c['unreviewed_internal_claims'],[('共同集合的两期各自权重仍会变化；见SymmetricSummary的within_rate与asset_weight贡献。','将算术贡献与因果判断分开，不将固定集合误作固定权重。'),(f'{len(priority)}+2×{len(states)}={minimum}人日，现有13不足，最少增加{gap}。','不把超预算计划作为已可执行；先申请额外1人日或明确约束变更。')])
 sheets.update(SymmetricBridge=pd.DataFrame(contributions),SymmetricSummary=pd.DataFrame(summaries),EffortPlan=plan,DecisionAudit=audit);base.xlsx(out/'credit_review.xlsx',sheets)
 register=pd.read_csv(out/'follow_up_register.csv')
 register=register.merge(plan[['CERT','current_base_days','conditional_full_review','conditional_extra_days','conditional_total_days','scope']],on='CERT',validate='one_to_one')
 base.csv(register,out/'follow_up_register.csv')
 append_memo(out/'credit_review_memo.docx','人力约束下的批准与变动分解',[f'八家基础核查8人日；三州各1次完整复核另需6人日，合计最少{minimum}，现有13不可满足全部约束。基础核查可先启动，完整方案尚待额外{gap}人日批准，不声称三州完整复核已全部获批。',f'条件方案完整复核CERT={sorted(full)}，该三家末期代理资产金额之和{score(full):.0f}千美元；其余五家保留基础核查。','共同银行仍存在权重变化。两种替换顺序平均后，银行内代理率贡献、权重贡献及额外范围差异合计等于观察变化；这是算术分解而非因果归因，不能与原2024固定权重变化混用。'],pd.DataFrame(summaries).round(6))
 return dict(minimum_days=minimum,additional_days=gap,full_review_CERT=sorted(full),full_proxy_amount=score(full))

def law(base,inp,out,c):
 sheets=pd.read_excel(out/'safeguards_gap_register.xlsx',sheet_name=None);rules=c['rules'];exports=rules['exports'];all_ids=set();covered=set();plaintext=set();ledger=[]
 for item in exports:
  ids=set(range(item['from_id'],item['to_id']+1));all_ids|=ids
  qualifies=item['encryption']=='plaintext' or item['key_obtained_by_attacker']
  if qualifies:covered|=ids
  if item['encryption']=='plaintext':plaintext|=ids
  ledger.append(dict(row_type='export',export=item['export'],records=len(ids),distinct_consumers=len(ids),notification_consumers=len(ids) if qualifies else 0,qualifies=qualifies,locator='decision_constraints.json rules.exports.'+item['export'],reason='明文或密钥被取得' if qualifies else '有效加密、密钥未泄露且有可靠证据排除仅C明文取得'))
 records=sum(x['records'] for x in ledger)
 ledger += [dict(row_type='summary',export='all_export_rows',records=records,distinct_consumers=len(all_ids),notification_consumers=len(covered),locator='A/B/C编号范围含首尾，跨文件按C编号去重'),dict(row_type='conditional_A_key_unknown',export='A_key_evidence_pending',distinct_consumers=len(all_ids),notification_consumers=f'{len(plaintext)}..{len(covered)}',locator='B明文为已确认下界，A密钥被获取时达到上界')]
 lower,upper=len(plaintext),len(covered);deadline=(date(2025,3,3)+timedelta(days=30)).isoformat()
 cases=pd.DataFrame([dict(case='C: all facts confirmed',consumers_maintained=4800,affected=upper,exemption='(b)(1),(d)(2),(h),(i)',FTC_notice='是' if upper>=500 else '不达500门槛',safeguards='原550案之外的独立反事实；全部事实03-03已知；最迟'+deadline),dict(case='C: A key unknown',consumers_maintained=4800,affected=f'{lower}..{upper}',FTC_notice='门槛取决于A密钥及未授权明文证据；不宣称已排除',safeguards='立即保全并优先核实密钥，必要时按原发现时点尽快准备通报，不以内部复核日重启时钟')])
 sheets['Scenarios']=pd.concat([sheets['Scenarios'],cases],ignore_index=True);sheets['ExposureLedger']=pd.DataFrame(ledger)
 sheets['DecisionAudit']=claim_rows(c['unreviewed_internal_claims'],[(f'导出记录{records}条，去重消费者{len(all_ids)}，基准通知事件涵盖{upper}人。','通知门槛使用符合定义的不同消费者，既不按文件行数也不把未解密C专有人数全算入。'),('4800人的例外只涉及(b)(1)/(d)(2)/(h)/(i)，不包括(j)。','基准反事实跨500应尽快向FTC通报；原550通报草稿仍保持原案。')]);base.xlsx(out/'safeguards_gap_register.xlsx',sheets)
 append_memo(out/'legal_action_memo.docx','独立反事实C：导出去重与缺证分支',[f'原案仍是550人，通报草稿未改写。反事实C单独计算：A320、B305、C200，共{records}条；A/B/C去重{len(all_ids)}名；A密钥被取得与B明文的并集{upper}人，C中额外95人未被据此算入通知事件。',f'基准C在03-03已知全部事实，达到500，仍须尽快、最迟{deadline}；4800人例外不免(j)。',f'若仅A密钥是否泄露待核实，B明文可确认{lower}人，若A密钥被取则上界{upper}，跨500结论取决于待核证据。立即保全密钥访问、解密及导出证据并升级合规负责人，不把缺证写成已排除或等到管理层复核才重新计时。','截至题设基准日未实际提交或通知，未编造修复完成；这些反事实不替换原案事实或原550人草稿。'])
 return dict(export_records=records,distinct_all=len(all_ids),notification_covered=upper,uncertain_key_lower=lower,uncertain_key_upper=upper)

def da(base,inp,out,c):
 sheets=pd.read_excel(out/'outdoor_activity_model.xlsx',sheet_name=None);cal=pd.read_csv(out/'review_calendar.csv',dtype={'FIPS':str});rules=c['rules'];budget=rules['discretionary_budget_per_month']
 cal['extra_candidate']=pd.to_numeric(cal.AQI,errors='coerce').between(101,150)
 cal['extra_room_cost']=np.where(cal.extra_candidate,cal.county.map(rules['additional_room_cost'])+pd.to_datetime(cal.date).dt.day_name().map(rules['weekday_adjustment']),0)
 cal['extra_service_points']=np.where(cal.extra_candidate,(cal.AQI-100)*cal.county.map(rules['service_priority_weight']),0).astype(int)
 cal['extra_funded']=False;summary=[];frontier=[]
 for month in sorted(cal.month.unique()):
  candidates=cal[cal.month.eq(month)&cal.extra_candidate];dp={0:(0,())}
  for dt,group in candidates.groupby('date',sort=True):
   nxt=dict(dp)
   for spend,(score,selected) in dp.items():
    for idx,row in group.iterrows():
     cost=spend+int(row.extra_room_cost)
     if cost>budget:continue
     choice=(score+int(row.extra_service_points),selected+(idx,))
     if cost not in nxt or choice[0]>nxt[cost][0] or (choice[0]==nxt[cost][0] and choice[1]<nxt[cost][1]):nxt[cost]=choice
   dp=nxt
  best_cost,best=max(dp.items(),key=lambda x:(x[1][0],-x[0]))
  if best[1]:cal.loc[list(best[1]),'extra_funded']=True
  greedy=[];dates=set();spend=0
  for idx,row in candidates.sort_values(['AQI','date','FIPS'],ascending=[False,True,True]).iterrows():
   if row.date not in dates and spend+row.extra_room_cost<=budget:greedy.append(idx);dates.add(row.date);spend+=int(row.extra_room_cost)
  greedy_score=int(cal.loc[greedy,'extra_service_points'].sum()) if greedy else 0
  summary.append(dict(month=month,candidates=len(candidates),budget=budget,funded=len(best[1]),spent=best_cost,unspent=budget-best_cost,optimal_service_points=best[0],highest_AQI_greedy_points=greedy_score,greedy_optimality_gap=best[0]-greedy_score,certificate='每个日期至多选一个县；ResourceFrontier保留全部可达终态费用及该费用最高积分，预算内取最大值。'))
  for cost,(score,selected) in sorted(dp.items()):frontier.append(dict(month=month,spend=cost,maximum_service_points=score,selected_calendar_rows=','.join(str(i+2) for i in selected)))
 cal['extra_spend']=np.where(cal.extra_funded,cal.extra_room_cost,0);cal['extra_awarded_points']=np.where(cal.extra_funded,cal.extra_service_points,0)
 cal['resource_action']=np.where(cal.extra_funded,'追加补贴支持全场室内',cal.action_B)
 plan=cal[cal.extra_candidate].copy();resource_summary=pd.DataFrame(summary)
 for month,group in cal[cal.extra_funded].groupby('month'):assert group.extra_spend.sum()<=budget and not group.date.duplicated().any()
 sheets.update(ResourcePlan=plan,ResourceSummary=resource_summary,ResourceFrontier=pd.DataFrame(frontier),DecisionAudit=claim_rows(c['unreviewed_internal_claims'],[(f'在日期冲突、县权重和不同费用下，AQI贪心无一般最优保证；本数据{int((resource_summary.greedy_optimality_gap>0).sum())}个月低于动态规划最优值。','按完整约束优化追加补贴，并保留可重算终态前沿。'),('B的超标室内、缺测备用和原室内选项资金已经独立落实，追加资金仅用于101–150全场转室内。','不能挪用或取消B基础安排；未获追加补贴仍执行B。')]));base.xlsx(out/'outdoor_activity_model.xlsx',sheets);base.csv(cal,out/'review_calendar.csv')
 append_memo(out/'activity_policy_brief.docx','有限追加补贴下的执行计划',[f'全年追加补贴安排{int(cal.extra_funded.sum())}场，费用{int(cal.extra_spend.sum())}美元，管理优先积分{int(cal.extra_awarded_points.sum())}；各月最多900、每日最多1县，月份余额不结转。','先按B执行已落实资金的超标室内/缺测备用和室内选项，再在101–150候选中选取追加全场室内。未选候选仍按B。县内场地各自存在，每日最多一县是中央协调限制，不是跨县共用物理场地。','最优性方法：将同日期候选作为互斥组，逐日期更新每个可达费用的最高积分；完整终态费用前沿和追溯行号见ResourceFrontier。给出的积分是内部管理偏好，不是健康效益或因果估计。'],resource_summary[['month','funded','spent','unspent','optimal_service_points','greedy_optimality_gap']])
 return dict(funded=int(cal.extra_funded.sum()),spent=int(cal.extra_spend.sum()),service_points=int(cal.extra_awarded_points.sum()),greedy_suboptimal_months=int((resource_summary.greedy_optimality_gap>0).sum()))

def ga(base,inp,out,c):
 sheets=pd.read_excel(out/'balance_review.xlsx',sheet_name=None);train=pd.read_csv(inp/'dota2Train.csv',header=None);frozen=sheets['FrozenSix'];rules=c['rules']
 clusters=sorted(train[1].value_counts().loc[lambda x:x>=rules['omitted_cluster_min_train_rows']].index.tolist());assert clusters
 rows=[]
 for cluster in clusters:
  remaining=train[train[1].ne(cluster)];globalp=remaining[0].eq(1).mean()
  grouped=remaining.groupby([1,2,3])[0].agg(n='size',p=lambda x:x.eq(1).mean())
  lookup={k:(r.p if r.n>=100 else globalp,int(r.n<100)) for k,r in grouped.iterrows()}
  lookup_values=[lookup.get(tuple(v),(globalp,1)) for v in remaining[[1,2,3]].itertuples(index=False,name=None)]
  p=np.array([v[0] for v in lookup_values]);fallback=np.array([v[1] for v in lookup_values]);labels=remaining[0].to_numpy()
  for hero in frozen.itertuples():
   sign=remaining[int(hero.csv_column)-1].to_numpy();active=sign!=0;n=int(active.sum());plus=int((sign==1).sum());minus=int((sign==-1).sum())
   win=(sign==labels)[active].mean();expected=np.where(sign==1,p,1-p)[active].mean();gap=100*(win-expected)
   supported=n>=500 and plus>=100 and minus>=100;consistent=gap*hero.adjusted_gap_pp>0
   rows.append(dict(omitted_cluster=int(cluster),omitted_train_rows=int(train[1].eq(cluster).sum()),H=hero.H,selection_direction=hero.direction,remaining_train_rows=len(remaining),remaining_n=n,remaining_n_plus=plus,remaining_n_minus=minus,adjusted_gap_pp=gap,full_train_gap_pp=hero.adjusted_gap_pp,supported=supported,strict_same_direction=consistent,fallback_share_pct=100*fallback[active].mean(),remaining_global_plus_win_pct=100*globalp))
 loo=pd.DataFrame(rows);allocation=[]
 for hero in frozen.itertuples():
  g=loo[loo.H.eq(hero.H)];allocation.append(dict(H=hero.H,selection_direction=hero.direction,scenarios=len(g),all_supported=bool(g.supported.all()),all_same_direction=bool(g.strict_same_direction.all()),upgrade_eligible=bool(g.supported.all() and g.strict_same_direction.all()),conservative_strength_pp=float(g.adjusted_gap_pp.abs().min()),full_test=False))
 allocation=pd.DataFrame(allocation);eligible=allocation[allocation.upgrade_eligible]
 options=[]
 for ids in itertools.combinations(eligible.H.tolist(),3):
  group=eligible[eligible.H.isin(ids)]
  if set(group.selection_direction)=={'high','low'}:options.append((float(group.conservative_strength_pp.sum()),tuple(sorted(ids))))
 chosen=sorted(options,key=lambda x:(-x[0],x[1]))[0] if options else None
 if chosen:allocation.loc[allocation.H.isin(chosen[1]),'full_test']=True
 allocation['test_level']=np.where(allocation.full_test,'完整受控试玩（待批准执行）','轻量证据收集')
 allocation['constraint_status']='三名额可行，覆盖high/low' if chosen else '约束不可行：不私换FrozenSix，需设计负责人调整资源/条件'
 sheets.update(LeaveClusterOut=loo,TestAllocation=allocation,DecisionAudit=claim_rows(c['unreviewed_internal_claims'],[(f'测试集同号只是一种验证，不排除训练cluster构成敏感性；追加分析含{len(clusters)}个整cluster剔除情景。','使用训练敏感性决定完整/轻量级别，不把保留方向复现当作排除混杂。'),('追加分配只读取训练数据和原FrozenSix，保留集不重估基线、不用于换名单。','保留一次测试复核的隔离，原六项不可因分配而替换。')]));base.xlsx(out/'balance_review.xlsx',sheets)
 queue=pd.read_csv(out/'playtest_queue.csv');queue=queue.merge(allocation[['H','upgrade_eligible','conservative_strength_pp','test_level','constraint_status']],on='H',validate='one_to_one');base.csv(queue,out/'playtest_queue.csv')
 append_memo(out/'balance_review_brief.docx','三个完整试玩名额的训练稳健性核验',[f'共{len(clusters)}个训练样本>=1000的cluster逐个剔除。每次用剩余训练重建分层及总体回退率，不重选FrozenSix，也不读取测试集重估。支持不足情景保留，不从分母静默删除。',f'所有情景支持>=500、每方>=100且严格同号才可升级。保守强度是各剔除情景绝对校正差最小值，不是统计置信下界。完整三项选择={list(chosen[1]) if chosen else "不可行"}；在方向覆盖约束下穷举原六项的三项组合验证最优，强度和={chosen[0] if chosen else None}。','其余项目保留轻量证据收集，不能因未获完整名额而换入新的保留集强项。原训练冻结六项和原测试复核数值未改；执行前仍需核实当前版本、英雄槽位、玩家与阵容等条件。'],allocation[['H','selection_direction','upgrade_eligible','conservative_strength_pp','test_level']].round(5))
 return dict(clusters=clusters,eligible=int(allocation.upgrade_eligible.sum()),full_test_H=list(chosen[1]) if chosen else [],objective=chosen[0] if chosen else None)

def main():
 p=argparse.ArgumentParser();p.add_argument('--domain',required=True);p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path);args=p.parse_args()
 base=load_base();args.output.mkdir(parents=True,exist_ok=True)
 original=getattr(base,args.domain.lower())(args.input,args.output)
 constraints=json.loads((args.input/'decision_constraints.json').read_text())
 extension=globals()[args.domain.lower()](base,args.input,args.output,constraints)
 print(json.dumps(dict(domain=args.domain,original=original,extension=extension,expert_gold_confirmed=False),ensure_ascii=False))

if __name__=='__main__':main()
